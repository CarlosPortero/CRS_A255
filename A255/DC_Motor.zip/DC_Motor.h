/* DC Motor library, for using DC Motors easily
 * 
 * Copyright (c) LLC - Carlos Portero Fernández <porterofernandezcarlos@gmail.com>
 *
 * Version 1.0 - initial release
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef DC_Motor_h
#define DC_Motor_h
#include "Encoder.h"
#include "WProgram.h"
#include "Arduino.h"

    long ISRCounter = 0;
    long counter = 0;

 class DC_Motor{
     private:
        int forward;
        int backward;
     public:
        Encoder encoder;
        long ISRCounter=0;
        long counter=0;
         DC_Motor(int forward,int backward,uint8_t pin1, uint8_t pin2):encoder(pin1,pin2){
                pinMode(forward, OUTPUT);
		        pinMode(backward, OUTPUT);
                this->forward=forward;
                this->backward=backward;
            }
        void Mover(int sentido,int maxsteps,int output){
          if (output > 210){
              output=210; //Establecimiento de velocidad maxima
          }
          if(output <=10){
              output=30; //Establecimiento de velocidad minima
          }
          if (sentido==1){
            ISRCounter=encoder.read();
            if (counter <= maxsteps && counter >= -maxsteps)
                { 
                analogWrite(forward,output);
                digitalWrite(backward,LOW);
                }
            else
                {
                analogWrite(forward,0);
                digitalWrite(backward,LOW);
                }
            }
            if(sentido1==2)
            {
            ISRCounter = encoder.read();
            if (counter <= maxsteps && counter >= -maxsteps)
            { 
                analogWrite(backward,output);
                digitalWrite(forward,LOW);
            }
            else
            {
            analogWrite(backward,0);
            digitalWrite(forward,LOW);
            }
            }
        else {
            ISRCounter=encoder.read();
             digitalWrite(forward,LOW);
             digitalWrite(backward,LOW);
            }
            
        }
        void Enlazar(){
            if(counter != ISRCounter){
                counter =  ISRCounter;
            }
        }
    
};

#endif